import Searchbox from './Searchbox.js'
import Hospital_data from './MOCK_DATA.json'
import Location from './Location.js'
import Address from './Address.js'
import Categorylist from './Categorylist.js'
import {AiOutlineArrowLeft} from 'react-icons/ai'
const Particular = () => {
  return (
    <div className="particularhospital">
      <div className="arrowicon"><AiOutlineArrowLeft size={25}/></div>
      <Location data={Hospital_data} />
      <Searchbox data={Hospital_data}/>
      <nav>
        <a className="needhelp" href="help">Need Help?</a>
        <a className="bellicon" href="bell"><img src="Vector (1).png" alt=" "/></a> 
        <a className="carticon" href="cart"><img src="Group 35.png" alt=" "/> </a>
      </nav>
      <div className="particulardetail">
          <Address />
          <button className="offerbar">General Checkup 60% Off using code: APOLLO</button>
          <Categorylist />    
      </div>
    </div>
  )
}

export default Particular
