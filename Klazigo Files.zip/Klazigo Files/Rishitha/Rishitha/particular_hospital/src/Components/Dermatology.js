
const Dermatology = () => {
  return (
    <div className="specialistcard">
      <img className="specialimage" src="Rectangle 62.png" alt=" "/>
      <a className="phygen" href="dermatology" style={{color:"black"}}>Dermatology</a>
      <p className="phydesc">For skin related diseases</p>
    </div>
  )
}

export default Dermatology
