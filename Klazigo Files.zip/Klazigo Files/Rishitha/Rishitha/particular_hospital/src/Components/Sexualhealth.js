
const Sexualhealth = () => {
  return (
    <div className="specialistcard">
      <img className="specialimage" src="Rectangle 64.png" alt=" "/>
      <a className="phygen" href="sexual health" style={{color:"black"}}>Sexual Health</a>
      <p className="phydesc">For sex related diseases</p>
    </div>
  )
}

export default Sexualhealth
