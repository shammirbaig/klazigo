import React from 'react'
import Header from './Header.js'
import Particular from './Particular.js'
import Footer from './Footer.js'
const App = () => {
  return (
    <div className="app">
      <Header/>
      <Particular/>
      <Footer/>
    </div>
  )
}

export default App

