import Physician from './Physician.js'
import Dermatology from './Dermatology.js'
import Sexualhealth from './Sexualhealth.js'
const Categorylist = () => {
  return (
    <div className="categorylist">
      <h3 style={{marginTop:"70px",marginLeft:"102px"}}>Doctor catogories in Apollo</h3>
          <div className="particularcard">
            <Physician />
            <Dermatology />
            <Sexualhealth />
            <Physician />
            <Dermatology />
            <Sexualhealth />
          </div> 
    </div>
  )
}

export default Categorylist
