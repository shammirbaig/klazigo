
const Physician = () => {
  return (
    <div className="specialistcard">
      <img className="specialimage" src="Rectangle 61.png" alt=" "/>
      <a className="phygen" href="generalphysician" style={{color:"black"}}>Genral Physician</a>
      <p className="phydesc">For Typhoids,Headaches,
      Migraine,infections</p>
    </div>
  )
}

export default Physician
