import React from 'react'

const Sort = () => {
  return (
    <div className="sortby">
      <p>Sort by:</p>
      <div className="func">
        <button>Fee</button>
        <button>Distance</button>
        <button>Rating</button>
      </div>
    </div>
  )
}

export default Sort
