import Hospitallistcard from './Hospitallistcard.js'
const Hospitals = () => {
  return (
    <div className="hosp">
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
        <Hospitallistcard />
    </div>
  )
}

export default Hospitals
