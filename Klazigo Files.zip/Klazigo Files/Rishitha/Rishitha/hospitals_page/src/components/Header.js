
import {BrowserRouter,Link} from "react-router-dom";

 
const Header = () => {
  return (
    <BrowserRouter>
      <div className="rectangle122">
        <img className="logo" src="3473b9 1.png" alt=" "/>
        <nav className="header">
          <Link class="top" to="/hospitals">Hospitals</Link>
          <Link class="top" to="/doctors">Doctors</Link>
          <Link class="top" to="/medicine">Medicine</Link>
          <Link class="top" to="/plus">Plus</Link>
          <Link class="top" to="offers">Offers</Link>
        </nav>
        <button className="login">Login/SignUp</button>
    </div>
    </BrowserRouter>
  )
}

export default Header
