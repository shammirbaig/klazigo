import {useState} from 'react'
import {AiTwotoneHeart} from 'react-icons/ai'
const Hospitallistcard = () => {
  const[state,setState]=useState(false);

  const changecolor=()=>{
    setState(!state);
  }
  return (
    <div className="hospitallist">
      <div className="hospimg">
        <img className="yashoda" src="image 7.png" alt="loading"/>
        <div className={state? "toggleafter":"heart"} onClick={changecolor}><AiTwotoneHeart size={25} /></div>
        <img className="staricon2" src="Group 71.png" alt=" "/>
      </div>
      <div className="hospimgdetalis">
        <div className="hospitaldetails">    
            <h4>Yashoda Hospital <img className="rating" style={{paddingLeft:"50px"}}src="Group 47.png" alt=""/></h4>
            <img className="multi" style={{padding:"2px"}} src="Group 45.png" alt=" "/>
            <img className="multi" style={{padding:"3px"}} src="Group 46.png" alt=" "/>
        </div>
        <div className="consult">
            <button className="book">Book Consultation</button>
        </div>
        <img className="filtericon" src="cil_filter.png" alt=" "></img>
      </div>  
    </div>
  )
}

export default Hospitallistcard
