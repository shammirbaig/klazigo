import React from 'react'
import Header from './Header.js'
import Hospitalmain from './Hospitalmain.js'
import Footer from './Footer.js'
const App = () => {
  return (
    <div className="app">
      <Header/>
      <Hospitalmain/>
      <Footer/>
    </div>
  )
}

export default App
