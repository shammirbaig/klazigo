
const Address = () => {
  return (
    <div className="addresscard">
        <div className="address">
            <h2>Apollo Hospital</h2>
            <p>Karbala Abbas Bagh,Hardoi Road,Balaganj,Lucknow,Uttar Pradesh 226003.</p>
            <a className="map" href="map">View map</a>
        </div> 
        <div className="vert"></div>
        <img className="hospitalimg" src="Rectangle 59.png" alt=" "/>
        <img className="staricon" src="Group 71.png" alt=" "/>
        <img className="feesicon" src="Group 78.png" alt=" "/>
        <img className="navicon" src="carbon_location-save.png" alt=" "/>
        <p className="disticon">5 Km</p>
        <div className="hor"></div>
    </div>
  )
}

export default Address
