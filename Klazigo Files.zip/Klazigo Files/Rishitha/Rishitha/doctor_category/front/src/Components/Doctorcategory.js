import Searchbox from './Searchbox.js'
import Location from './Location.js'
import Hospital_data from "./MOCK_DATA.json"
import Address from './Address.js'
import Doctorcardlist from './Doctorcardlist.js'
import {AiOutlineArrowLeft} from 'react-icons/ai'


const Doctorcategory = ({fav,setFav}) => {
  return (
    <div className="doctorcat">
      <div className="arrowicon"><AiOutlineArrowLeft size={25}/></div>
      <Location data={Hospital_data} />
      <Searchbox data={Hospital_data} />
      <nav>
        <a className="needhelp" href="help">Need Help?</a>
        <a className="bellicon" href="bell"><img src="Vector (1).png" alt=" "/></a> 
        <a className="carticon" href="cart"><img src="Group 35.png" alt=" "/> </a>
      </nav>
      <div className="doccategory">
        <Address />
        <button className="offerbar">General Checkup 60% Off using code: APOLLO</button>
        <Doctorcardlist fav={fav} setFav={setFav} />
      </div>
    </div>
  )
}

export default Doctorcategory
