import React from 'react'

const Favorites = ({fav,setFav}) => {
  return (
    <div className="favcontainer">
        {
            fav.map((val=>(
                <div className="doctorcard">
                    <div className="doctorname"><h4>{val.name}</h4></div>
                    <p className="docexp">{val.exp}</p>
                    <p className="availability">{val.avail}</p>
                    <button className="slotbook">Book A Slot</button>
                </div>
        )))}
    </div>
  )
}

export default Favorites
