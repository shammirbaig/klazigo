import Bottomcontent from './Bottomcontent.js'
const Footer = () => {
  return (
    <div className="container">
        <div className="column1">
            <p className="mainheading">Klazigo</p>
            <div className="columndetails">
              <a href="about">About Us</a> 
              <a href="blog">Blog</a>
              <a href="career">Careers</a>
              <a href="press">Press</a>
              <a href="faq">FAQ</a>
              <a href="contact">Contact Us</a>
            </div>
        </div>
        <div className="column2">
          <p className="heading">For Patients</p>
          <Bottomcontent />
        </div>
        <div className="column3">
          <p className="heading">For Doctors</p>
          <Bottomcontent />
        </div>
        <div className="column4">
          <p className="heading">For Hospitals</p>
          <Bottomcontent />
        </div>
        <div className="column5">
          <p className="heading">For Medical Stores</p>
          <Bottomcontent />
        </div>
        <div className="column6">
          <p className="heading">More</p>
          <div className="lastcolumn">
            <a href="help">Help</a>
            <a href="developers">Developers</a>
            <a href="privacy">Privacy Policy</a>
            <a href="terms">Terms & Conditions</a>
            <a href="license">Licenses</a>
          </div>
        </div>
        <img className="klazigologo" src="klazigologo.jpg" alt=" "/>
        <p className="last">All Rights Reserved</p>
    </div>
  )
}

export default Footer
