import {useState} from 'react'

const Searchbox = ({data}) => {
    const[searchname,setSearchname]=useState([]);
    const shownames=(e)=>{
        const searchword=e.target.value;
        const datafilter=data.filter((value)=>{
            return value.hospital_name.toLowerCase().includes(searchword);
        });
        if(searchword==="")
        {
            setSearchname([]);
        }
        else{setSearchname(datafilter);}     
    }
  return (
    <div className="searchbox">
        <div className="searchbar">
          <img src="Vector.png" alt=" "/>
          <input type="text" name="search" placeholder="Search hospitals..." onChange={shownames}></input>
        </div>
        {searchname.length !==0 && (
            <div className="dataresult">
                {searchname.map((val,key)=>{
                    return <a className="dataitem" href="hospital"><p>{val.hospital_name},{val.street},{val.city}</p></a>
                })}
            </div>
        )}
     </div>
  )
}

export default Searchbox
