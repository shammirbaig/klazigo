const Bottomcontent = () => {
  return (
    <div className="contentdetails">
      <a href="hospitals">Search for Hospitals</a>
      <a href="clinics"> Search for Clinics</a>
      <a href="doctors">Search for docotrs</a>
      <a href="articles">Health Articles</a>
      <a href="healthapp">Health App</a>
    </div>
  )
}

export default Bottomcontent
