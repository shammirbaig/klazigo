import Header from './Header.js'
import Footer from './Footer.js'
import Doctorcategory from './Doctorcategory.js'
import {useState} from 'react'



const App = () => {
  const[fav,setFav]=useState([]);
  return (
    <div className="app">
      <Header />
      <Doctorcategory fav={fav} setFav={setFav} />
      <Footer />
    </div>
  )
}

export default App
