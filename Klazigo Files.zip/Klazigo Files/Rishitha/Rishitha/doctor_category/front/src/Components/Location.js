import {useState} from 'react'
const Location = ({data}) => {
  const[location,setLocation]=useState([]);

  const showlocation=(e)=>{
    const searchword=e.target.value;
    const datafilter=data.filter((value)=>{
        return value.city.toLowerCase().includes(searchword);
    });
    if(searchword==="")
    {
        setLocation([]);
    }
    else{setLocation(datafilter);}     
}
  return (
    <div className="locationbar">
        <img className="locationicon" src="Vector (2).png" alt=" "/>
        <input className="locname" type="text" placeholder="Location" onChange={showlocation}></input>
        <img className="locationicon" src="Vector (3).png" alt=" "/>
    {location.length !==0 && (
      <div className="locationresult">
          {location.map((val,key)=>{
              return <option>{val.city}</option>
          })}
        </div>
        )}
  </div>
  )
}

export default Location
