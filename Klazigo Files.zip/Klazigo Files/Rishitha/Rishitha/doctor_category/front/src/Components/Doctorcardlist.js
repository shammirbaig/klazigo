import Doctorcard from './Doctorcard.js'
import {useState} from 'react'
import doctor_data from './DOCTOR_DATA.json'

const Doctorcardlist = ({fav,setFav}) => {
  const[doclist]=useState(doctor_data);
  return (
    <div className="doctorlist">
      <div className="docheading"><h3>General Physicians</h3></div>
        <div className="particulardoc">
          {doclist.map((val=>(
            <Doctorcard val={val} fav={fav} setFav={setFav}/>
          )))}
        </div>
    </div>
  )
}

export default Doctorcardlist
