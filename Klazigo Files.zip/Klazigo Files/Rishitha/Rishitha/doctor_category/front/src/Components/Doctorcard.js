import {AiTwotoneHeart} from 'react-icons/ai'
import {useState} from 'react'

const Doctorcard = ({val,fav,setFav}) => {
  const[state,setState]=useState(false);

  const changecolor=()=>{
    setState(!state);
    fav.includes(val) ? (setFav(fav.filter((c)=>c.id !== val.id))) : (setFav([...fav,val]));
  }
  return (
    <div className="doctorcard">
      <img className="doctorimage" src="Rectangle 5.png" alt=" "/>
      <div className={state? "toggleafter":"heart"} onClick={changecolor}><AiTwotoneHeart size={25} /></div>
      <img className="staricon2" src="Group 71.png" alt=" "/>
      <div className="doctorname"><h4>{val.name}</h4></div>
      <p className="docexp">{val.exp}</p>
      <p className="availability">{val.avail}</p>
      <button className="slotbook">Book A Slot</button>
    </div>
  )
}

export default Doctorcard
