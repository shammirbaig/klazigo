

const num1=10;
const num2=20;
const addition=()=>{
    console.log(`addition is ${num1+num2}`);
}
addition()