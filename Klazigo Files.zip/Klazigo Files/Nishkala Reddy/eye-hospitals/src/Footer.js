import React from "react";
import './footer.css';
function Footer(){
    return(
        <div className="below">
        <div className="footer">
            <div className="line1">
            <p className="linehead1">Klazigo</p>
            <p >About Us</p>
            <p >Blog</p>
            <p >Careers</p>
            <p >Press</p>
            <p >FAQ</p>
            <p>Contact Us</p>
        </div>
        <div className="line2">
        <p className="linehead2">For Patients</p>
        <p>Search for Hospitals</p>
        <p>Search for Clinics</p>
        <p>Search for Doctors</p>
        <p>Health Articles</p>
        <p>Health App</p>
        </div>
        <div className="line2">
        <p className="linehead2">For Doctors</p>
        <p>Search for Hospitals</p>
        <p>Search for Clinics</p>
        <p>Search for Doctors</p>
        <p>Health Articles</p>
        <p>Health App</p>
        </div>
        <div className="line2">
        <p className="linehead2">For Hospitals</p>
        <p>Search for Hospitals</p>
        <p>Search for Clinics</p>
        <p>Search for Doctors</p>
        <p>Health Articles</p>
        <p>Health App</p>
        </div>
        <div className="line2">
        <p className="linehead2">For Medical stores</p>
        <p>Search for Hospitals</p>
        <p>Search for Clinics</p>
        <p>Search for Doctors</p>
        <p>Health Articles</p>
        <p>Health App</p>
        </div>
        <div className="line2">
        <p className="linehead2">More</p>
        <p>Help</p>
        <p>Developers</p>
        <p>Privacy Policy</p>
        <p>Terms & Conditions</p>
        <p>Licenses</p>
        </div>
        </div>
        <img className="footerlogo" src="/images/White 1.png"/>
        <br/>
        <p className="rights">All Rights Reserved</p>
        </div>
    );
}
export default Footer;