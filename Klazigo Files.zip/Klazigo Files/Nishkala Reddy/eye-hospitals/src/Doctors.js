import React from "react";
function Doctors(){
    return(
        <div className="doctors">
            <h1>Doctors page</h1>
        </div>
        
    );
}
export default Doctors;