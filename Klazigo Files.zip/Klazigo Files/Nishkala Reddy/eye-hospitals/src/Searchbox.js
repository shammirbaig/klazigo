// // import React,{useState} from "react";
// import React,{useState} from 'react';
// import './search.css';
// function Searchbar({data}){
//   const [filteredData,setFilteredData]=useState([]);
//   const handleFilter=(event)=>{
//     const searchword=event.target.valiue;
//     const newFilter=data.filter((value)=>{
//         return value.name.toLowerCase().include(searchword.toLowerCase());
//     });
//     if(searchword===""){
//       setFilteredData([])
//     }
//     else{
//     setFilteredData(newFilter);
//     }
// };
// return(
//   <div className="search">
//   <div className="searchInputs">
//   <input type="text" placeholder="Search hospitals..." onChange={handleFilter}/>
//   <img className="searchimg" src="/images/search.png" alt="noimage"/>
//   </div>
//   {filteredData.length!==0 &&(
//     <div className="dataResult">
//     {filteredData.map((value,key)=>{
//       return(
//         <a className="dataItem" href=""><p>{value.name}</p></a>
//       );
//     })}
//     </div>
//   )}
// </div>

// );
// }
// export default Searchbar;
import {useState} from 'react';
import './search.css';

const Searchbox = ({data}) => {
    const[searchname,setSearchname]=useState([]);
    const shownames=(e)=>{
        const searchword=e.target.value;
        const datafilter=data.filter((value)=>{
            return value.hospital_name.toLowerCase().includes(searchword);
        });
        if(searchword==="")
        {
            setSearchname([]);
        }
        else{setSearchname(datafilter);}     
    }
  return (
    <div className="searchbox">
        <div className="searchbar">
          <img src="/images/search.png" alt=" "/>
          <input type="text" name="search" placeholder="Search hospitals..." onChange={shownames}></input>
        </div>
        {searchname.length !==0 && (
            <div className="dataresult">
                {searchname.map((val,key)=>{
                    return <a className="dataitem" href="hospital"><p>{val.hospital_name},{val.street},{val.city}</p></a>
                })}
            </div>
        )}
     </div>
  )
}

export default Searchbox