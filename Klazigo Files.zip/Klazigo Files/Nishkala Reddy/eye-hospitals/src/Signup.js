
import './login.css';
import Signcard from './Signcard';
import Slideshow from './Slideshow';
import './signup.css';
function Signup() {
  return (
        <div className='signup'>
        <table >
        <tr>
          <td><Slideshow/></td>
          <td><Signcard/><img className='into' src='/images/into.png'/></td>
        </tr>
      </table>
      </div>
      
  );
}

export default Signup;