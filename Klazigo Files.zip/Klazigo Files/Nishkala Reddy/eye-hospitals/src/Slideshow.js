import React from "react";
import './slideshow.css';
function Slideshow(){
    return(<div class="showcard">
    <div class="card_part card_part-one">
    <div className="slidecard">
        <img className="adimage" src="/images/image 5.png" alt="image"/>
        <p className="title_ad">Book an appointment</p>
        <p className="content1">Never waste your time againby waiting in</p>
        <p className="content2"> your near by hospitals and clinics</p>
    </div>
    </div>
    <div class="card_part card_part-two">
    <div className="slidecard">
        <img className="adimage" src="/images/image 5.png" alt="image"/>
        <p className="title_ad">Book an appointment</p>
        <p className="content1">Never waste your time againby waiting in</p>
        <p className="content2"> your near by hospitals and clinics</p>
    </div>
    </div>
    
    <div class="card_part card_part-three">
    <div className="slidecard">
        <img className="adimage" src="/images/image 5.png" alt="image"/>
        <p className="title_ad">Book an appointment</p>
        <p className="content1">Never waste your time againby waiting in</p>
        <p className="content2"> your near by hospitals and clinics</p>
    </div>
    </div>
    <div class="card_part card_part-four">
    <div className="slidecard">
        <img className="adimage" src="/images/image 5.png" alt="image"/>
        <p className="title_ad">Book an appointment</p>
        <p className="content1">Never waste your time againby waiting in</p>
        <p className="content2"> your near by hospitals and clinics</p>
    </div>
    </div>
  
  </div>);
}
export default Slideshow;