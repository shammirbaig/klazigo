// import './App.css';
import Logincard from './Logincard';
import './login.css';
import Slideshow from './Slideshow';
import Verify from './Verify';
import Signup from './Signup';
function Login() {
  return (
    <div className="register">
      <div className='login'>
        <table >
        <tr>
          <td><Slideshow/></td>
          <td><Logincard/><img className='into' src='/images/into.png'/></td>
        </tr>
      </table>
      </div>
    </div>