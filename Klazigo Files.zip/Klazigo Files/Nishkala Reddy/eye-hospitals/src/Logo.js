import React from'react';
import './Logo.css';
function Logo(){
    return(
      <img className="imgs2" src="/images/3473b9 1.png"/>
    );
  }
  export default Logo;
