import React from "react";
import './Card.css';
function Card() {
  return (
    <div className="card">
      <img className="imgdesktop" src="/images/image 7.png" />
      <div className="card_bottom">
        <p className="card_title">Yashoda Hospital</p>
        <p className="card_stars">⭐️⭐️⭐️⭐️</p>
        <p className="card_description">Multi-speciality</p>
        <p className="card_stars"><img src="/images/Vector.png"/>5km</p>
        <p className="card_text">Consulation fee of</p>
        <p className="card_stars"><img src="/images/carbon_currency-rupee.png"/>150</p>
      </div>
      <button className="btns">Book Consulation</button>
      </div>

  );
}
export default Card;
