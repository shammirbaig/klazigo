import React from 'react';
import './Location.css';
function Location(){
    return(
        <div className='location'>
            <img className="locationmark" src="/images/Locationmark.png"/>
            <input className="locationinput" type="text" placeholder='New Delhi-101010' />
            <img className="gps" src="/images/Gps.png"/>
        </div>
    );
}
export default Location;