import React from "react";
import './hospital.css';
import Card from './Card';
import Searchbox from './Searchbox';
import Hospital_data from "./sampledata.json";
import Location from './Location';
function Hospital() {
  return (
    <div className="hospital">
      <hr className="line" />
      <div className="firstline">
        <Location />
        <Searchbox data={Hospital_data} />
        <p className="help">Need Help?</p>
        <img className="bell" src="/images/Bell.png" />
        <img className="cart" src="/images/Group 35.png" />
      </div>
      <p className="hospitalpath"><a className="underline" src="">Homepage</a>  >  <a className="underline" src="">Eye Hospitals</a></p>
      <div className="Secondline">
      <h5 className="sub-title">Eye Hospitals</h5>
      <p className="secondline_filter">SortBy:</p>
      <p className="secondline_filter_fee">Fee</p>
      <p className="secondline_filter_distance">Distance</p>
      <p className="secondline_filter_rating">Rating</p>
      <img className="filter" src="/images/filter.png"/>
      </div>
      <div className="hospitalgrids">
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
       <Card/>
      </div>
    </div>
  );
}

export default Hospital;
