import React from 'react';
import './Navbar.css';
import Logo from './Logo';
function Navbar(){
  return(
    <div className="navbars">
       <nav class="navbar navbar-expand-sm">
       <a class="navbar-brand" to="/logo"><Logo/></a>
        <ul class="navbar-nav ">
          <li class="nav-item">
            <a class="nav-link" to="/hospitals">Hospitals</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/doctors">Doctors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/medicine">Medicine</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/plus">Plus</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/offers">Offers</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/bts"><button className="button2">Login/Signup</button></a>
          </li>
        </ul>
      </nav>
    </div>
  );
}
export default Navbar;
