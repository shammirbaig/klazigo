import React from "react";
import './App.css';
import Hospital from "./Hospital";
import Navbar from './Navbar';
import Footer from './Footer';
import Card from "./Card";
function App() {
  return (
    <div className="app">
      <Navbar/> 
       <Hospital/>
      <Footer/>
    </div>
  );
}

export default App;
