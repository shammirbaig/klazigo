import React from "react";
import './final.css';
function Final(){
    return(
    <div className="final">
        <img className="fpic" src="/images/Success.png"/>
        <p className="msg">Login Successfull</p>
    </div>
    );
}
export default Final;