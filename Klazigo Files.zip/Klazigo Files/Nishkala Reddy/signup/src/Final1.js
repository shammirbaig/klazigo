import React from "react";
import './final1.css';
function Final1(){
    return(
    <div className="final1">
        <img className="fpic1" src="/images/Success.png"/>
        <p className="msg1">Signup Successfull</p>
    </div>
    );
}
export default Final1;