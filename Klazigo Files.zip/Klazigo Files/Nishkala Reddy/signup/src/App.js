import './App.css';
import Signcard from './Signcard';
import Slideshow from './Slideshow';
import Verify from './Verify';
import Login from './Login';
import Final1 from './Final1';
function App() {
  return (
    <div className="App">
    <div className="signup">
      <table >
      <tr>
        <Login/>
      </tr>
    </table>
    </div>
      {/* <Login/> */}
      {/* <Final1/> */}
    </div>
  );
}

export default App;
