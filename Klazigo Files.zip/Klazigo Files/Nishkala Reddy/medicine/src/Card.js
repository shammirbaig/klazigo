import React from "react";
import './Card.css';
function Card(props){
  return(
    <div className="card">
      <img className="imgs" src={props.ims}/>
        <p className="texts">{props.text}</p>
   </div>


  );
}
export default Card;
