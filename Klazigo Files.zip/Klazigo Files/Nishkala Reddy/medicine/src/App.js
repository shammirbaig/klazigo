import React from "react";
import './App.css';
import Navbar from './Navbar';
import Popular from "./Popular";
import Concern from "./Concern";
import Searchbox from './Searchbox';
import Footer from "./Footer";
import Hospital_data from "./sampledata.json";
// import Card from "./Card";
import Previoulsy from "./Previously";
import Location from "./Location";

function App() {
  return (
    <div className="App">
    <Navbar/>  
    <hr className="line"/>
    <p className="loc"><img className="locimg" src="/Images/location.png"/>purani Haveli..</p>
    <div className="firstline">
    <Location/>
    <Searchbox className="smallsearch" data={Hospital_data}/>
    <p className="help">Need Help?</p>
    <img className="bell" src="/Images/Bell.png"/>
    <img className="cart" src="/Images/Group 35.png"/>
    </div>
    <p className="path"><a className="underline" src="">Homepage</a>  >  <a className="underline" src="">medicine</a></p>
    <p className="title">Medicine and health Products</p>
    <Popular/>
    <Previoulsy/>
    <Concern/>
    <Footer/>
    </div>
  );
}

export default App;
