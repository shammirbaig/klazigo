import React from 'react';
import './Navbar.css';
import Logo from './Logo';
function Navbar(){
  return(
    <div className="navbars">
       <nav class="navbar navbar-expand-sm">
       <a class="navbar-brand" to="/logo"><Logo/></a>
        <ul class="navbar-nav ">
          <li class="nav-item">
            <a class="nav-link" to="/">Hospitals</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/">Doctors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/">Medicine</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/">Plus</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/">Offers</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" to="/"><button className="button2">Login/Signup</button></a>
          </li>
        </ul>
      </nav>
    </div>
  );
}
export default Navbar;
