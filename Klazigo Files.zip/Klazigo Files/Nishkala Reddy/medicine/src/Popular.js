import React from "react";
import Card from "./Card";
import './Popular.css'
function Popular(){
    return(
        <div className="popular">
            <p className="category">Popular Categories</p>
            <div class="populargrid">
                    <div ><Card ims="/Images/Rectangle 96.png" text="Winter Care"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Skin Care"/></div>
                    <div ><Card ims="/Images/Rectangle 96.png" text="Diabetic Care"/></div>
                    <div ><Card ims="/Images/Rectangle 96.png" text="Ayurvedic"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Health Drinks"/></div>
                    <div ><Card ims="/Images/Rectangle 96.png" text="Vitamins and Suppliments"/></div>
                    <div ><Card ims="/Images/Rectangle 96.png" text="Baby Care"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Homeopathy"/></div>
                    <div ><Card ims="/Images/Rectangle 96.png" text="Protein supplements"/></div>
                    <div ><Card ims="/Images/Rectangle 96.png" text="Immunity Boosters"/></div> 
                    <div><Card ims="/Images/Rectangle 96.png" text="Health Care devices"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Mineral supplements"/></div> 
                </div>
                <hr className="gap1"/>
            </div>
    
    );
}
export default Popular;