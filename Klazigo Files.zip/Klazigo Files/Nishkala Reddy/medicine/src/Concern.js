import React from "react";
import Card from "./Card";
import './Concern.css'
function Concern(){
    return(
        <div className="concern">
            <p className="cat">Concern Based categories</p>
            <div class="concerngrids">
                    <div><Card ims="/Images/Rectangle 96.png" text="Respiratory Care"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Kidney Care"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="HairCare"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Liver Care"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Diabetes care"/></div>
                    <div><Card ims="/Images/Rectangle 96.png" text="Cardiac care"/></div>
            </div>
            <hr className="gap3"/>
        </div>
    
    );
}
export default Concern;