import React from 'react';
import './Location.css';
function Location(){
    return(
        <div className='location'>
            <img className="locationmark" src="/Images/Locationmark.png"/>
            <input className="locationinput" type="text" placeholder='New Delhi-101010' />
            <img className="gps" src="/Images/Gps.png"/>
        </div>
    );
}
export default Location;